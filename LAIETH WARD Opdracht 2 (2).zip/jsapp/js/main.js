var nav = [{name:'Projecten' , link:'Projecten.html', type:'internal'},{name:'Graduaat' , link:'Graduat.html', type:'internal'}
			,{name:'Programmeren' , link:'Programmeren.html', type:'internal'},{name:'Programmeren1' , link:'Programmeren1.html', type:'internal'}];
var navigation='';			
			for (var j = 0; j < nav.length; j++){
					navigation+='<li style="float:left; margin-left:20px;padding:10px;"><a href="'+nav[j].link+'">'+nav[j].name+'</a></li>';
			}

var eventss = [{name:'Interactieve workshops voor leerlingen laatste graad secundair onderwijs' , link:'https://www.arteveldehogeschool.be/dienstverlening/diensten-voor-scholen/winterlab'},
{name:'Workshops "Zeg het met 3D, Code, Kleur, Beeld en geluid"' , link:'https://ahsdevelopers.github.io/zeghetmetkleur/'}
			,{name:'Studie-informatiedagen (SID-ins): aanbod aan studie- en beroepsmogelijkheden na je secundair onderwijs' , link:'https://www.arteveldehogeschool.be/bij-ons-studeren/kom-kennismaken/sid-ins'},
			{name:'Infodag zaterdag 11 maart 2023 (10:00 tot 17:00)' , link:'https://www.arteveldehogeschool.be/bij-ons-studeren/kom-kennismaken/infodagenS'}
			 
			];
var events='';			
			for (var j = 0; j < eventss.length; j++){
					events+='<li style="float:left; margin-left:6px;padding:10px;"><a href="'+eventss[j].link+'">'+eventss[j].name+'</a></li>';
			}


var projectss = [{id:'1' , name:'Dialectische Gedragstherapie(DGT)', synopsis:'Webapp ter ondersteuning van Dialectische Gedragstherapie (DGT)',
				 author:{firstname:'Charlotee',lastname:'Delvaux',technologies:[{id:'1',name:'Angular',screenshots:''},
				 																 {id:'1',name:'NetJS',screenshots:''}
																				 ]}
				},
				{id:'2' , name:'Buurtakajs Gent', synopsis:'Native mobile applicatie om kajaks te reserveren in Gent',
				 author:{firstname:'Dylan',lastname:'Cathejilin',
				 		  technologies:[{ id:'1', name:'React Native',screenshots:''},
						  				{ id:'2', name:'Firebase', screenshots:''}
										
						  				]
						}
				},
				{id:'3' , name:'Tekst.ai', synopsis:'Een gebruiksvriendelijk en personaliseerbaar dashboard voor Tekst.ai',
				 author:{firstname:'Jan',lastname:'Dischacht',
				 		  technologies:[{ id:'1', name:'Next JS',screenshots:''},
						  				{ id:'2', name:'Strapi', screenshots:''}
										
						  				]
						}
				},
				{id:'4' , name:'Virtural Closet', synopsis:'Sociale applicatie om kleding (uit jouw kledingkast) te matchen tot een goede outfit door andere gebruikers',
				 author:{firstname:'Thabisa',lastname:'Dingani',
				 		  technologies:[{ id:'1', name:'React Native',screenshots:''},
						  				{ id:'2', name:'Firebase', screenshots:''}
										
						  				]
						}
				},
				{id:'5' , name:'Car expense', synopsis:'Platform om kosten van een auto te bijhouden inclusief speech-to-text',
				 author:{firstname:'Jamie-Lee',lastname:'Hart',
				 		  technologies:[{ id:'1', name:'React JS',screenshots:''},
						  				{ id:'2', name:'Supabase', screenshots:''}
										
						  				]
						}
				},
				{id:'6' , name:'Crypto Tracker', synopsis:'Mobiele (native) applicatie voor het tracken van cryptomunten',
				 author:{firstname:'Aiden',lastname:'Soufi',
				 		  technologies:[{ id:'1', name:'React Native',screenshots:''},
						  				{ id:'2', name:'Firebase', screenshots:''}
										
						  				]
						}
				},
				{id:'7' , name:'La Macarena', synopsis:'Website voor La Macarena, een organisatie die verschillende activeiten organiseert voor jonge vrouwen',
				 author:{firstname:'Nicolas',lastname:'Cnudde',
				 		  technologies:[{ id:'1', name:'VueJS',screenshots:''},
						  				{ id:'2', name:'GraphQL', screenshots:''}
										
						  				]
						}
				},
				{id:'8' , name:'TorchLight', synopsis:'Mobiele applicatie om characters bij te houden tijdens een Dungeons and Dragons spel',
				 author:{firstname:'Bram',lastname:'Vadenbussche',
				 		  technologies:[{ id:'1', name:'Angular',screenshots:''},
						  				{ id:'2', name:'Firebase', screenshots:''}
										
						  				]
						}
				},
				{id:'6' , name:'DisoverSound', synopsis:'Webapplicatie waarbij je willekeurige nummers te horen krijgt van onbekende bands',
				 author:{firstname:'Bram',lastname:'Criel	',
				 		  technologies:[{ id:'1', name:'ReactJS',screenshots:''},
						  				{ id:'2', name:'Firebase', screenshots:''}
										
						  				]
						}
				},
				 ];

var projects='';			
for (var j = 0; j < projectss.length; j++){
		var technologiess= projectss[j].author.technologies;
		console.log(technologiess);
		var technologies='';
		for (var i = 0; i < technologiess.length; i++){
			technologies+='<span style="color:grey; padding:10px;">'+technologiess[i].name+'</span>';
		}
		projects+='<div class="sproject" onClick="showpopup('+j+');"  id="sproject'+j+'"> <img class"pimg" src="images/e'+j+'.png"><br><br><span style="color:grey; padding:10px;">'+projectss[j].author.firstname+' '+projectss[j].author.lastname+'</span><br><h4>'+ projectss[j].name+'</h4>'+technologies+'<p id="desc'+j+'" class="desc">'+projectss[j].synopsis+'</p></div>';
}
 
   var sociall = [{name:'Facebook' , link:'https://www.facebook.com/Programmeren.ahs', img:'facebook.png'},{name:'LinkedIn' , link:'https://www.linkedin.com/company/28878545/admin/',img:'linkedin.png'},
   					{name:'Youtube' , link:'https://www.youtube.com/channel/UCHly8VZULSMWEmvbPJNVtFA',img:'youtube.png'},{name:'Instagram' , link:'https://www.instagram.com/programmeren.ahs/',img:'instagram.png'},
					{name:'pgm' , link:'http://www.pgm.gent',img:'vs.png'}
			 ];
var social='';			
			for (var j = 0; j < sociall.length; j++){
					social+='<li style="float:left; margin-left:20px;padding:10px;"><a href="'+sociall[j].link+'"><img class="simg" src="images/'+sociall[j].img+'"><a></li>';
			}

window.addEventListener('DOMContentLoaded', (event) => {
    document.getElementById('navigation').innerHTML=navigation;
	 document.getElementById('events').innerHTML=events; 
	 document.getElementById('projects').innerHTML=projects;
	 document.getElementById('social').innerHTML=social;
});	 

function showpopup(id){
	document.getElementById('desc'+id).style.display="block";
	document.getElementById('two').innerHTML = document.getElementById('sproject'+id).innerHTML; 
	change();
}
function change() {
  document.getElementById('visible').style.top = "0";
  document.getElementById('visible-block').style.top = "0";
}
function rrr() {

  for (let el of document.querySelectorAll('.desc')) el.style.visibility = 'hidden';

  document.getElementById('visible').style.top = "-100%";
  document.getElementById('visible-block').style.top = "-100%";
}