function generateDigitalClockUTCAsString () {
	var timestamp = 1663569900000;
	var dateFuture = new Date(timestamp);
	var dateNow = new Date();
	
	var seconds = Math.floor(((dateNow)- dateFuture )/1000);
	var minutes = Math.floor(seconds/60);
	var hours = Math.floor(minutes/60);
	var days = Math.floor(hours/24);
	
	hours = hours-(days*24);
	minutes = minutes-(days*24*60)-(hours*60);
	seconds = seconds-(days*24*60*60)-(hours*60*60)-(minutes*60);
	
	
	
    //const date = new Date(timestamp);
	
   // date.setHours(date.getHours() + utc + date.getTimezoneOffset()/60);
    return days+' days    '+hours+'h     '+minutes+'m  '+seconds+'s';
  }
  function generateDigitalClockUTCAsString1 () {
	var timestamp = 1695019500000;
	var dateFuture = new Date(timestamp);
	var dateNow = new Date();
	
	var seconds = Math.floor((  dateFuture -(dateNow))/1000);
	var minutes = Math.floor(seconds/60);
	var hours = Math.floor(minutes/60);
	var days = Math.floor(hours/24);
	
	hours = hours-(days*24);
	minutes = minutes-(days*24*60)-(hours*60);
	seconds = seconds-(days*24*60*60)-(hours*60*60)-(minutes*60);
	
	
	
    //const date = new Date(timestamp);
	
   // date.setHours(date.getHours() + utc + date.getTimezoneOffset()/60);
    return days+' days    '+hours+'h     '+minutes+'m  '+seconds+'s';
  }
 
  
  function ticking () {
	 document.getElementById('timeticking').innerHTML=`${generateDigitalClockUTCAsString()}`;
	  document.getElementById('timeticking1').innerHTML=`${generateDigitalClockUTCAsString1()}`;
    //console.log(`${generateDigitalClockUTCAsString(2, 'Ghent')}`);
  }
  setInterval(ticking, 1000);